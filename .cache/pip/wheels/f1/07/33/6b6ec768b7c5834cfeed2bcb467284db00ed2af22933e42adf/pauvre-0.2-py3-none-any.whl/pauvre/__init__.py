from pauvre.version import __version__
